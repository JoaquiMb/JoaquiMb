---
"@primer/css": patch
---

Adding .color-bg-transparent utility class
