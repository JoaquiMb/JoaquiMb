---
"@primer/css": patch
---

Fix color-fg utilities in links
