module.exports = {
  extends: ['@primer/stylelint-config'],
  ignoreFiles: ['**/*.js', '**/*.cjs'],
  rules: {
    'primer/no-override': false
  }
}
